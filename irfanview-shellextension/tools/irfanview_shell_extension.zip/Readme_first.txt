-----------------------------------------------------------------------------
File  : 'Readme_first.txt' - Information for IrfanView Shell Extension
Author: Irfan Skiljan
E-Mail: irfanview@gmx.net
WWW   : http://www.irfanview.com
-----------------------------------------------------------------------------

*******	IrfanView Shell Extension *******
	This PlugIn shows a Context menu for some IrfanView (4.38 and later) 
        operations in Windows Explorer, Total Commander or other file managers.
	You can select several (picture) files and perform IrfanView operations:
	- Play slideshow with selected files (using current IrfanView slideshow dialog settings)
	- Open selected files in IrfanView Thumbnails window
	- JPG Lossless Rotation (automatic rotation, based on EXIF orientation, optimize ON, keep all markers ON)
	- Convert pictures/images to another format (same folder, copies will be created if the result file already exists)
	Thanks to Michael Dunn!
*******

Download:

You can download the PlugIn from the Internet:
   http://www.irfanview.com/plugins.htm
   http://www.irfanview.net/plugins.htm



- How to install IrfanView Shell Extension?

  1) Visit IrfanView's homepage: http://www.irfanview.com
  2) Go to "Download->PlugIns" and look for 'Shell Extension' infos
  3) Download and start the Shell Extension installer
     Note for Windows Vista and later: Admin Rights are required!
  4) The Shell Extension will be installed into IrfanView "Shell Extension" folder 
     and you can use it via Context menu in Windows Explorer etc.
     Menu item: "IrfanView operations"
  5) Note for updates: Windows restart can be required for changes in system shell extensions

  Infos for manual install/updates (from ZIP file):
  a) Note for Windows Vista and later: Admin Rights are required!
  b) Rename the old extension DLL file
  c) Unzip/copy the new DLL file into the "Shell Extension" folder
  d) Start "install.bat" file (as ADMIN (!), for your 32 or 64 bit Windows) to register the new extension file
  e) Windows restart can be required for changes in system shell extensions


- How to uninstall IrfanView Shell Extension?

  1) Note for Windows Vista and later: Admin Rights are required!
     You have to start your file manager (like Windows Explorer, Total Commander etc.)
     in ADMIN mode (right mouse button click on program, then "Run as administrator".
  2) Go to your IrfanView folder, subfolder: "Shell Extension" and choose your 
     Windows system: 32 or 64 bit
  3) Start the file "uninstall.bat" (as ADMIN (!), to unregister the extension from context menu
  4) If you want to delete the "Shell Extension" folder, you have to restart Windows
     to unload/unlock the shell extension DLL file, then you can delete it
-----------------------------------------------------------------------------
